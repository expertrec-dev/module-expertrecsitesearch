<?php
/**
 * Copyright © 2015 Expertrec . All rights reserved.
 */
namespace Expertrec\ExpertrecSiteSearch\Block\Adminhtml\Integration;
class StoreMid extends \Magento\Backend\Block\Template
{

	
}
